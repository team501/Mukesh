var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Tile = /** @class */ (function (_super) {
    __extends(Tile, _super);
    function Tile() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Tile.prototype.remove = function () {
        this.props.remove(this.props.index);
    };
    Tile.prototype.render = function () {
        return React.createElement("div", { className: "tile", draggable: true },
            React.createElement("div", { style: { borderBottom: '1px solid #e0e0e0', padding: '4px', display: 'flex', cursor: 'move' } },
                React.createElement("div", { style: { flexGrow: 1, color: '#005c9c', fontWeight: 'bold' } }, this.props.header),
                React.createElement("div", { className: "buttons" },
                    React.createElement("span", { className: "glyphicon glyphicon-pencil", title: "Edit Tile" }),
                    React.createElement("span", { className: "glyphicon glyphicon-remove", title: "Close Tile", onClick: this.remove.bind(this) }))),
            React.createElement("div", { style: { display: 'flex', alignItems: 'center', justifyContent: 'center', padding: '4px' } },
                React.createElement("div", null, this.props.content)));
    };
    return Tile;
}(React.Component));
//# sourceMappingURL=Tile.js.map