var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var RadialGauge = /** @class */ (function (_super) {
    __extends(RadialGauge, _super);
    function RadialGauge() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    RadialGauge.prototype.render = function () {
        var lastItem = this.props.data.items[this.props.data.items.length - 1];
        return React.createElement("div", null,
            React.createElement("h3", null,
                "Profit for ",
                wijmo.Globalize.format(lastItem.date, 'MMMM yyyy')),
            React.createElement(Wj.RadialGauge, { min: 0, max: 1000, format: "c0", value: lastItem.profit }));
    };
    return RadialGauge;
}(React.Component));
//# sourceMappingURL=RadialGauge.js.map