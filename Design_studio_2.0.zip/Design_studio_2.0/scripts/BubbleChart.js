var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BubbleChart = /** @class */ (function (_super) {
    __extends(BubbleChart, _super);
    function BubbleChart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BubbleChart.prototype.render = function () {
        return React.createElement(Wj.FlexChart, { chartType: wijmo.chart.ChartType.Bubble, itemsSource: this.props.data, bindingX: "date" },
            React.createElement(Wj.FlexChartAxis, { wjProperty: "axisX", format: "MMM-yy" }),
            React.createElement(Wj.FlexChartAxis, { wjProperty: "axisY", title: "Sales (Bubble size indicates profit)" }),
            React.createElement(Wj.FlexChartSeries, { name: "Sales/Profit", binding: "sales,profit" }),
            React.createElement(Wj.FlexChartLegend, { position: wijmo.chart.Position.None }));
    };
    return BubbleChart;
}(React.Component));
//# sourceMappingURL=BubbleChart.js.map