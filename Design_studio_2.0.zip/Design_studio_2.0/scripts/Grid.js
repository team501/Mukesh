var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Grid = /** @class */ (function (_super) {
    __extends(Grid, _super);
    function Grid() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    Grid.prototype.render = function () {
        return React.createElement(Wj.FlexGrid, { isReadOnly: true, headersVisibility: wijmo.grid.HeadersVisibility.Column, selectionMode: wijmo.grid.SelectionMode.ListBox, itemsSource: this.props.data },
            React.createElement(Wj.FlexGridColumn, { header: "ID", binding: "id", width: 40 }),
            React.createElement(Wj.FlexGridColumn, { header: "Date", binding: "date", format: "MMM yyyy" }),
            React.createElement(Wj.FlexGridColumn, { header: "Sales", binding: "sales", format: "c" }),
            React.createElement(Wj.FlexGridColumn, { header: "Expenses", binding: "expenses", format: "c" }),
            React.createElement(Wj.FlexGridColumn, { header: "Profit", binding: "profit", format: "c" }));
    };
    return Grid;
}(React.Component));
//# sourceMappingURL=Grid.js.map