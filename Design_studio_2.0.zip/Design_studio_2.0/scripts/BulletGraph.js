var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BulletGraph = /** @class */ (function (_super) {
    __extends(BulletGraph, _super);
    function BulletGraph() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BulletGraph.prototype.render = function () {
        return React.createElement("div", null,
            React.createElement("h3", null, "Profits"),
            React.createElement("table", { className: "table condensed" },
                React.createElement("tbody", null, this.props.data.items.map(function (item, index) {
                    return React.createElement("tr", { key: index },
                        React.createElement("td", null, wijmo.Globalize.format(item.date, 'MMM yyyy')),
                        React.createElement("td", null,
                            React.createElement("span", { className: "label label-danger", style: { borderRadius: '1em', display: item.profit <= 400 ? '' : 'none' } }, "!")),
                        React.createElement("td", null,
                            React.createElement(Wj.BulletGraph, { value: item.profit, min: 0, bad: 400, target: 600, good: 600, max: 1000 })));
                }))));
    };
    return BulletGraph;
}(React.Component));
//# sourceMappingURL=BulletGraph.js.map