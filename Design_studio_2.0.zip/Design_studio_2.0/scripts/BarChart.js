var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var BarChart = /** @class */ (function (_super) {
    __extends(BarChart, _super);
    function BarChart() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    BarChart.prototype.render = function () {
        return React.createElement(Wj.FlexChart, { chartType: wijmo.chart.ChartType.Bar, itemsSource: this.props.data, bindingX: "date" },
            React.createElement(Wj.FlexChartAxis, { wjProperty: "axisX", format: "MMM-yy" }),
            React.createElement(Wj.FlexChartSeries, { name: "Sales", binding: "sales" }),
            React.createElement(Wj.FlexChartSeries, { name: "Expenses", binding: "expenses" }),
            React.createElement(Wj.FlexChartSeries, { name: "Profit", binding: "profit", chartType: wijmo.chart.ChartType.LineSymbols }));
    };
    return BarChart;
}(React.Component));
//# sourceMappingURL=BarChart.js.map