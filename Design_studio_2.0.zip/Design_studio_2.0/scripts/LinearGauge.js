var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var LinearGauge = /** @class */ (function (_super) {
    __extends(LinearGauge, _super);
    function LinearGauge() {
        return _super !== null && _super.apply(this, arguments) || this;
    }
    LinearGauge.prototype.render = function () {
        var lastItem = this.props.data.items[this.props.data.items.length - 1];
        return React.createElement("div", null,
            React.createElement("h3", null,
                "KPIs for ",
                wijmo.Globalize.format(lastItem.date, 'MMMM yyyy')),
            React.createElement("h4", null,
                "Sales: ",
                wijmo.Globalize.format(lastItem.sales, 'c')),
            React.createElement(Wj.LinearGauge, { min: 0, max: 1000, thumbSize: 30, value: lastItem.sales, pointer: { color: 'green' } }),
            React.createElement("h4", null,
                "Expenses: ",
                wijmo.Globalize.format(lastItem.expenses, 'c')),
            React.createElement(Wj.LinearGauge, { min: 0, max: 1000, thumbSize: 30, value: lastItem.expenses, pointer: { color: 'red' } }),
            React.createElement("h4", null,
                "Profit: ",
                wijmo.Globalize.format(lastItem.profit, 'c')),
            React.createElement(Wj.LinearGauge, { min: 0, max: 1000, thumbSize: 30, value: lastItem.profit, pointer: { color: 'gold' } }));
    };
    return LinearGauge;
}(React.Component));
//# sourceMappingURL=LinearGauge.js.map