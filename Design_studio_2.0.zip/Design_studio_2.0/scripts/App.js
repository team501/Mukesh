var __extends = (this && this.__extends) || (function () {
    var extendStatics = Object.setPrototypeOf ||
        ({ __proto__: [] } instanceof Array && function (d, b) { d.__proto__ = b; }) ||
        function (d, b) { for (var p in b) if (b.hasOwnProperty(p)) d[p] = b[p]; };
    return function (d, b) {
        extendStatics(d, b);
        function __() { this.constructor = d; }
        d.prototype = b === null ? Object.create(b) : (__.prototype = b.prototype, new __());
    };
})();
var Wj = wijmo.react;
var App = /** @class */ (function (_super) {
    __extends(App, _super);
    function App() {
        var _this = _super !== null && _super.apply(this, arguments) || this;
        // tile names and types
        _this.tileCatalog = [
            { name: 'Grid', tile: Grid },
            { name: 'Radial Gauge', tile: RadialGauge },
            { name: 'Linear Gauge', tile: LinearGauge },
            { name: 'Bar Chart', tile: BarChart },
            { name: 'Column Chart', tile: ColumnChart },
            { name: 'Line Chart', tile: LineChart },
            { name: 'Bubble Chart', tile: BubbleChart },
            { name: 'Bullet Graph', tile: BulletGraph },
            { name: 'Blank', tile: Blank }
        ];
        _this.key = 0;
        _this.state = {
            tileCatalog: new wijmo.collections.CollectionView(_this.tileCatalog),
            tiles: _this.getTiles(),
            key: _this.key,
            data: new wijmo.collections.CollectionView(_this.getData()) // data shown in the tiles
        };
        return _this;
    }
    App.prototype.getTiles = function () {
        // tiles currently in use (start with the first four)
        var tiles = [];
        for (var i = 0; i < 2; i++) {
            tiles.push({ name: this.tileCatalog[i].name, key: this.key++ });
        }
        return tiles;
    };
    App.prototype.getData = function () {
        // generate some data to show in the tiles
        var data = [], today = new Date();
        for (var i = 0; i < 12; i++) {
            var sales = 100 + Math.random() * 800 + i * 50, expenses = 50 + Math.random() * 300 + i * 5;
            data.push({
                id: i,
                date: wijmo.DateTime.addMonths(today, 12 - i),
                sales: sales,
                expenses: expenses,
                profit: sales - expenses
            });
        }
        ;
        return data;
    };
    // gets a tile content by name
    App.prototype.getTileContent = function (name) {
        var arr = this.state.tileCatalog.items;
        for (var i = 0; i < arr.length; i++) {
            if (arr[i].name == name) {
                return React.createElement(arr[i].tile, { data: this.state.data });
            }
        }
        throw '*** tile not found: ' + name;
    };
    // adds a tile to the dashboard
    App.prototype.addTile = function () {
        var tiles = this.state.tiles.slice(), key = this.state.key + 1;
        tiles.push({ name: this.state.tileCatalog.currentItem.name, key: key });
        this.setState({ tiles: tiles, key: key });
    };
    // removes a tile from the dashboard
    App.prototype.removeTile = function (tileIndex) {
        var tiles = this.state.tiles.filter(function (item, index) {
            return index != tileIndex;
        });
        this.setState({ tiles: tiles });
    };
    // initialize component after it has been mounted
    App.prototype.componentDidMount = function () {
        var _this = this;
        // enable tile drag/drop
        var panel = document.querySelector('.dashboard');
        this.enableItemReorder(panel);
        // update all tiles on sort (since last item changes)
        this.state.data.collectionChanged.addHandler(function () {
            _this.forceUpdate();
        });
    };
    App.prototype.componentWillUnmount = function () {
        this.state.data.collectionChanged.removeAllHandlers();
    };
    // allow users to re-order elements within a panel element
    // we work with the DOM elements and update the state when done.
    App.prototype.enableItemReorder = function (panel) {
        var _this = this;
        var dragSource = null, dropTarget = null;
        // add drag/drop event listeners
        panel.addEventListener('dragstart', function (e) {
            var target = wijmo.closest(e.target, '.tile');
            if (target && target.parentElement == panel) {
                dragSource = target;
                wijmo.addClass(dragSource, 'drag-source');
                var dt = e.dataTransfer;
                dt.effectAllowed = 'move';
                dt.setData('text', dragSource.innerHTML);
            }
        });
        panel.addEventListener('dragover', function (e) {
            if (dragSource) {
                var tile = wijmo.closest(e.target, '.tile');
                if (tile == dragSource) {
                    tile = null;
                }
                if (dragSource && tile && tile != dragSource) {
                    e.preventDefault();
                    e.dataTransfer.dropEffect = 'move';
                }
                if (dropTarget != tile) {
                    wijmo.removeClass(dropTarget, 'drag-over');
                    dropTarget = tile;
                    wijmo.addClass(dropTarget, 'drag-over');
                }
            }
        });
        panel.addEventListener('drop', function (e) {
            if (dragSource && dropTarget) {
                // finish drag/drop
                e.stopPropagation();
                e.stopImmediatePropagation();
                e.preventDefault();
                // re-order HTML elements (optional here, we're updating the state later)
                var srcIndex = getIndex(dragSource), dstIndex = getIndex(dropTarget), refChild = srcIndex > dstIndex ? dropTarget : dropTarget.nextElementSibling;
                dragSource.parentElement.insertBefore(dragSource, refChild);
                // focus and view on the tile that was dragged
                dragSource.focus();
                // update state
                var tiles = _this.state.tiles.slice();
                tiles.splice(srcIndex, 1);
                tiles.splice(dstIndex, 0, _this.state.tiles[srcIndex]);
                _this.setState({ tiles: tiles });
            }
        });
        panel.addEventListener('dragend', function (e) {
            wijmo.removeClass(dragSource, 'drag-source');
            wijmo.removeClass(dropTarget, 'drag-over');
            dragSource = dropTarget = null;
        });
        function getIndex(e) {
            var p = e.parentElement;
            for (var i = 0; i < p.children.length; i++) {
                if (p.children[i] == e)
                    return i;
            }
            return -1;
        }
    };
    // render the dashboard
    App.prototype.render = function () {
        var _this = this;
        var data = this.state.data;
        return React.createElement("div", null,
            React.createElement("div", { className: "header" },
                React.createElement("div", { className: "container" },
                    
                    
                    React.createElement("p", null, ""))),
            React.createElement("div", { className: "container" },
                
                
                React.createElement("div", { className: "container row" },
                    React.createElement("label", null,
                        "Select a tile type: ",
                        ' ',
                        React.createElement(Wj.ComboBox, { itemsSource: this.state.tileCatalog, displayMemberPath: "name" }),
                        ' ',
                        React.createElement("button", { className: "btn btn-primary", onClick: this.addTile.bind(this) }, "Add Tile to Dashboard"))),
                React.createElement("hr", null),
                React.createElement("div", { className: "dashboard" }, this.state.tiles.map(function (item, index) {
                    return React.createElement(Tile, { header: item.name, content: _this.getTileContent(item.name), remove: _this.removeTile.bind(_this), index: index, key: item.key });
                }))));
    };
    return App;
}(React.Component));
//# sourceMappingURL=App.js.map