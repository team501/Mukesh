import React from "react";
import PropTypes from "prop-types";
import _ from "lodash";
import { Responsive, WidthProvider } from "react-grid-layout";
const ResponsiveReactGridLayout = WidthProvider(Responsive);
import '../node_modules/react-grid-layout/css/styles.css';
import '../node_modules/react-resizable/css/styles.css';

export default class ShowcaseLayout extends React.Component {

  static defaultProps = {
    className: "layout",
    rowHeight: 30,
    cols: { lg: 12, md: 10, sm: 6, xs: 4, xxs: 2 },
  };
  

  constructor(props) {
    super(props);
    
    this.state = {
      items: [].map(function(i, key, list) {
        return {
          i: i.toString(),
          x: i * 2,
          y: 0,
          w: 2,
          h: 2,
          add: i === (list.length - 1).toString()
        };
      }),
      newCounter: 0,
      value: 'select'
    };
    this.onAddItem = this.onAddItem.bind(this);
    this.onAddNew = this.onAddNew.bind(this);
    this.onBreakpointChange = this.onBreakpointChange.bind(this);
    this.handleChange = this.handleChange.bind(this);
    console.log("insode constructor");
  }
  createElement(el) {
    const removeStyle = {
      position: "absolute",
      right: "2px",
      top: 0,
      cursor: "pointer"
    };
    const i = el.add ? "+" : el.i;
    return (
      <div key={i} data-grid={el}>
        {el.add ? (
          <span
            className="add text"
            onClick={this.onAddNew}
            title="You can add an item by clicking here, too."
          >
            Add +
          </span>
        ) : (
          <span className="text">{i}</span>
        )}
        <span
          className="remove1"
          style={removeStyle}
          onClick={this.onRemoveItem.bind(this, i)}
        >
          x
        </span>
      </div>
    );
  }
  handleChange(event) {
    this.setState({ value: event.target.value });
  }
  onAddItem() {
    /*eslint no-console: 0*/

    this.setState({
      // Add a new item. It must have a unique key!
      items: this.state.items.concat({
        i: "n" + this.state.newCounter,
        x: (this.state.items.length * 2) % (this.state.cols || 12),
        y: Infinity, // puts it at the bottom
        w: 2,
        h: 2
      }),
      // Increment the counter to ensure key is always unique.
      newCounter: this.state.newCounter + 1
    });
  }
  onAddNew() {
    /*eslint no-console: 0*/
    if(this.state.value == 'select'){
      alert('Please select a component to add');
    }
    else{
      if(this.state.items.length == 0){
        this.setState({
            // Add a new item. It must have a unique key!
            items: this.state.items.concat({
              i: this.state.value,
              x: (this.state.items.length * 2) % (this.state.cols || 12),
              y: Infinity, // puts it at the bottom
              w: 2,
              h: 2
            })
          });	
        
      }
      else{
        let itemList = this.state.items;
        let iList = [];
        
        //Store already available values to exclude duplicates
        itemList.map((i, key, list) => {
            iList.push(i.i);
          })
          //Condition to exclude duplicates 
          if(!(iList.includes(this.state.value))){
            this.setState({
                // Add a new item. It must have a unique key!
                items: this.state.items.concat({
                  i: this.state.value,
                  x: (this.state.items.length * 2) % (this.state.cols || 12),
                  y: Infinity, // puts it at the bottom
                  w: 2,
                  h: 2
                })
              });	    	
          }
      }
    }
}
  onRemoveItem(i) {
    this.setState({ items: _.reject(this.state.items, { i: i }) });
  }
 

  onBreakpointChange(breakpoint) {
    this.setState({
      currentBreakpoint: breakpoint
    });
  }
 
  render() {
    return (
      <div>
        <div style={{float: 'left'}}>
	      <select onChange={this.handleChange} value={this.state.value}>
	        <option value="select">Select</option>
	        <option value="Component 1">Component 1</option>
	        <option value="Component 2">Component 2</option>
	        <option value="Component 3">Component 3</option>
	        <option value="Component 4">Component 4</option>
	      </select>
	      <button className="uk-button uk-button-mini" onClick={this.onAddNew}>Add Component</button> 
    </div>
        <button>Save</button>
        <ResponsiveReactGridLayout
          {...this.props}
         
          onBreakpointChange={this.onBreakpointChange}
          
        >
          {_.map(this.state.items, el => this.createElement(el))}
        </ResponsiveReactGridLayout>
      </div>
    );
  }
}


