Please only submit bugs to this tracker. If you have a feature request, please implement it. This is free software and the author is busy with other projects.

Please use the [CodeSandbox Template](https://codesandbox.io/s/5wy3rz5z1x?module=%2Fsrc%2FShowcaseLayout.js) to demonstrate your bug. It is much easier for us to help you if you do.
